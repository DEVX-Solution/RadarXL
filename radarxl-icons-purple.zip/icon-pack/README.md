# RadarXL — Ícones da identidade visual

Pacote de ícones SVG lineares usado como referência para os mockups roxos do RadarXL.

- Estilo: outline / Lucide-style
- Cor padrão: `currentColor`, permitindo aplicar a cor roxa via CSS
- Uso recomendado: 20–24 px, stroke-width 2
- Os SVGs são arquivos independentes e podem ser usados em HTML, React, Vue ou CSS.

Observação: as mockups foram geradas como imagens e os ícones nelas estão incorporados. Este pacote contém as versões SVG independentes equivalentes ao conjunto visual utilizado.
